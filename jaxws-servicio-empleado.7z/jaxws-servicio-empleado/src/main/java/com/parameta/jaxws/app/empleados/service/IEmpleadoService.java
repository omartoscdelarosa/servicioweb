package com.parameta.jaxws.app.empleados.service;

import com.parameta.jaxws.app.empleados.dto.EmpleadoDTO;

/**
 *
 * @author Omar Toscano
 */
public interface IEmpleadoService {
    
    public Boolean saveEmpleado(EmpleadoDTO empleadoDTO);
}
