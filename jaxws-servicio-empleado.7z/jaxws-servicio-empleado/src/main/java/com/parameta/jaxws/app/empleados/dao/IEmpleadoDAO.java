package com.parameta.jaxws.app.empleados.dao;

import com.parameta.jaxws.app.empleados.models.Empleado;

/**
 *
 * @author Omar Toscano
 */
public interface IEmpleadoDAO {
    public Boolean saveEmpleado(Empleado empleado);
}
