package com.parameta.jaxws.app.empleados.service;

import com.parameta.jaxws.app.empleados.dao.EmpleadoDAOImpl;
import com.parameta.jaxws.app.empleados.dao.IEmpleadoDAO;
import com.parameta.jaxws.app.empleados.dto.EmpleadoDTO;
import com.parameta.jaxws.app.empleados.models.Empleado;

/**
 *
 * @author Omar Toscano
 */
public class EmpleadoServiceImpl implements IEmpleadoService{

    @Override
    public Boolean saveEmpleado(EmpleadoDTO empleadoDTO) {
        IEmpleadoDAO empleadoDAO = new EmpleadoDAOImpl();
        
        Empleado empleado = new Empleado();
        empleado.setApellidos(empleadoDTO.getApellidos());
        empleado.setCargo(empleadoDTO.getCargo());
        empleado.setFechaNacimiento(empleadoDTO.getFechaNacimiento());
        empleado.setFechaVinculacion(empleadoDTO.getFechaVinculacion());
        empleado.setNombre(empleadoDTO.getNombre());
        empleado.setNumeroDocumento(empleadoDTO.getNumeroDocumento());
        empleado.setSalario(empleadoDTO.getSalario());
        empleado.setTipoDocumento(empleadoDTO.getTipoDocumento());
        
        boolean isCreate = empleadoDAO.saveEmpleado(empleado);
        return isCreate;
    }
    
}
