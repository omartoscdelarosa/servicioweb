package com.parameta.jaxws.app.empleados.ws;

import com.parameta.jaxws.app.empleados.dto.EmpleadoDTO;
import com.parameta.jaxws.app.empleados.service.EmpleadoServiceImpl;
import com.parameta.jaxws.app.empleados.service.IEmpleadoService;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;

/**
 *
 * @author Omar Toscano
 */
@WebService(serviceName = "Empleado")
@Stateless()
public class Empleado {

    /**
     * Web service operation
     * @param empleado
     * @return 
     */
    @WebMethod(operationName = "saveEmpleado")
    public Boolean saveEmpleado(@WebParam(name = "empleado") EmpleadoDTO empleado) {
        IEmpleadoService empleadoService = new EmpleadoServiceImpl();
        
        return empleadoService.saveEmpleado(empleado);
    }


}
