/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.parameta.jaxws.app.empleados.dao;

import com.parameta.jaxws.app.empleados.models.Empleado;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Omar Toscano
 */
public class EmpleadoDAOImpl implements IEmpleadoDAO{
    
    EntityManagerFactory emf =
        Persistence.createEntityManagerFactory("pu-parameta");
    
    @Override
    public Boolean saveEmpleado(Empleado empleado) {
        EntityManager em = emf.createEntityManager();
        boolean isCreate = true;
        try{
            em.getTransaction().begin();
            em.persist(empleado);
            em.getTransaction().commit();
        }catch(Exception ex){
            isCreate = false;
            ex.printStackTrace();
        }finally{
            em.close();
        }
        return isCreate;
    }
    
}
