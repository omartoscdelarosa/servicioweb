package com.parameta.spingboot.app.empleados.client;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

@XmlRegistry
public class ObjectFactory {
	
	private final static QName _EmpleadoDTO_QNAME = new QName("http://ws.empleados.app.jaxws.parameta.com/", "EmpleadoDTO");
    private final static QName _SaveEmpleado_QNAME = new QName("http://ws.empleados.app.jaxws.parameta.com/", "saveEmpleado");
    private final static QName _SaveEmpleadoResponse_QNAME = new QName("http://ws.empleados.app.jaxws.parameta.com/", "saveEmpleadoResponse");
    
    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.parameta.jaxws.app.empleados.ws
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link EmpleadoDTO }
     * 
     */
    public EmpleadoDTO createEmpleadoDTO() {
        return new EmpleadoDTO();
    }

    /**
     * Create an instance of {@link SaveEmpleado }
     * 
     */
    public SaveEmpleado createSaveEmpleado() {
        return new SaveEmpleado();
    }

    /**
     * Create an instance of {@link SaveEmpleadoResponse }
     * 
     */
    public SaveEmpleadoResponse createSaveEmpleadoResponse() {
        return new SaveEmpleadoResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmpleadoDTO }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link EmpleadoDTO }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.empleados.app.jaxws.parameta.com/", name = "EmpleadoDTO")
    public JAXBElement<EmpleadoDTO> createEmpleadoDTO(EmpleadoDTO value) {
        return new JAXBElement<EmpleadoDTO>(_EmpleadoDTO_QNAME, EmpleadoDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveEmpleado }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SaveEmpleado }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.empleados.app.jaxws.parameta.com/", name = "saveEmpleado")
    public JAXBElement<SaveEmpleado> createSaveEmpleado(SaveEmpleado value) {
        return new JAXBElement<SaveEmpleado>(_SaveEmpleado_QNAME, SaveEmpleado.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveEmpleadoResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SaveEmpleadoResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.empleados.app.jaxws.parameta.com/", name = "saveEmpleadoResponse")
    public JAXBElement<SaveEmpleadoResponse> createSaveEmpleadoResponse(SaveEmpleadoResponse value) {
        return new JAXBElement<SaveEmpleadoResponse>(_SaveEmpleadoResponse_QNAME, SaveEmpleadoResponse.class, null, value);
    }

}
