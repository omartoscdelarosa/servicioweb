package com.parameta.spingboot.app.empleados.validators;

public interface DateValidator {
	
	public boolean esValida(String fecha);

}
