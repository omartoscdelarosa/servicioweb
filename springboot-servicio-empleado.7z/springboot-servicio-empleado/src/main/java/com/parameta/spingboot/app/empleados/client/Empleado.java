package com.parameta.spingboot.app.empleados.client;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.Action;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(targetNamespace = "http://ws.empleados.app.jaxws.parameta.com/", name = "Empleado")
@XmlSeeAlso({ObjectFactory.class})
public interface Empleado {
	
	 @WebMethod
	    @Action(input = "http://ws.empleados.app.jaxws.parameta.com/Empleado/saveEmpleadoRequest", output = "http://ws.empleados.app.jaxws.parameta.com/Empleado/saveEmpleadoResponse")
	    @RequestWrapper(localName = "saveEmpleado", targetNamespace = "http://ws.empleados.app.jaxws.parameta.com/", className = "com.parameta.spingboot.app.empleados.client.SaveEmpleado")
	    @ResponseWrapper(localName = "saveEmpleadoResponse", targetNamespace = "http://ws.empleados.app.jaxws.parameta.com/", className = "com.parameta.spingboot.app.empleados.client.SaveEmpleadoResponse")
	    @WebResult(name = "return", targetNamespace = "")
	    public java.lang.Boolean saveEmpleado(

	        @WebParam(name = "empleado", targetNamespace = "")
	        EmpleadoDTO empleado
	    );
}
