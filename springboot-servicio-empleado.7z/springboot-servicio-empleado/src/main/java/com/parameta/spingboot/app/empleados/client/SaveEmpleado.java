package com.parameta.spingboot.app.empleados.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "saveEmpleado", propOrder = {
    "empleado"
})
public class SaveEmpleado {

    protected EmpleadoDTO empleado;

    /**
     * Obtiene el valor de la propiedad empleado.
     * 
     * @return
     *     possible object is
     *     {@link EmpleadoDTO }
     *     
     */
    public EmpleadoDTO getEmpleado() {
        return empleado;
    }

    /**
     * Define el valor de la propiedad empleado.
     * 
     * @param value
     *     allowed object is
     *     {@link EmpleadoDTO }
     *     
     */
    public void setEmpleado(EmpleadoDTO value) {
        this.empleado = value;
    }

}
