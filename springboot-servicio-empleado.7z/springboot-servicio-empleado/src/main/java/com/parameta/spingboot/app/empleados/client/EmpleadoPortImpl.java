package com.parameta.spingboot.app.empleados.client;

import java.util.logging.Logger;


@javax.jws.WebService(
        serviceName = "Empleado",
        portName = "EmpleadoPort",
        targetNamespace = "http://ws.empleados.app.jaxws.parameta.com/",
        wsdlLocation = "http://localhost:8080/jaxws-servicio-empleado/Empleado?wsdl",
        endpointInterface = "com.parameta.spingboot.app.empleados.client.Empleado")

public class EmpleadoPortImpl implements Empleado {

	private static final Logger LOG = Logger.getLogger(EmpleadoPortImpl.class.getName());

	/* (non-Javadoc)
	* @see com.parameta.jaxws.app.empleados.ws.Empleado#saveEmpleado(com.parameta.jaxws.app.empleados.ws.EmpleadoDTO empleado)*
	*/
	public java.lang.Boolean saveEmpleado(EmpleadoDTO empleado) {
		LOG.info("Executing operation saveEmpleado");
		System.out.println(empleado);
		try {
			java.lang.Boolean _return = Boolean.valueOf(true);
			return _return;
		} catch (java.lang.Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException(ex);
		}
	}
}


