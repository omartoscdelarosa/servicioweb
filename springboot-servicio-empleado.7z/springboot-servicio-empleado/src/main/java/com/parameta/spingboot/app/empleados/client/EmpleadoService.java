package com.parameta.spingboot.app.empleados.client;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import javax.xml.ws.WebEndpoint;
import javax.xml.ws.WebServiceClient;
import javax.xml.ws.WebServiceFeature;

@WebServiceClient(name = "Empleado",
	wsdlLocation = "http://localhost:8080/jaxws-servicio-empleado/Empleado?wsdl",
	targetNamespace = "http://ws.empleados.app.jaxws.parameta.com/")
public class EmpleadoService extends Service{
	
	public final static URL WSDL_LOCATION;
	
	public final static QName SERVICE = new QName("http://ws.empleados.app.jaxws.parameta.com/", "Empleado");
	
    public final static QName EmpleadoPort = new QName("http://ws.empleados.app.jaxws.parameta.com/", "EmpleadoPort");
    
    static {
        URL url = null;
        try {
            url = new URL("http://localhost:8080/jaxws-servicio-empleado/Empleado?wsdl");
        } catch (MalformedURLException e) {
            java.util.logging.Logger.getLogger(EmpleadoService.class.getName())
                .log(java.util.logging.Level.INFO,
                     "Can not initialize the default wsdl from {0}", "http://localhost:8080/jaxws-servicio-empleado/Empleado?wsdl");
        }
        WSDL_LOCATION = url;
    }
    
    public EmpleadoService(URL wsdlLocation) {
        super(wsdlLocation, SERVICE);
    }

    public EmpleadoService(URL wsdlLocation, QName serviceName) {
        super(wsdlLocation, serviceName);
    }

    public EmpleadoService() {
        super(WSDL_LOCATION, SERVICE);
    }

    public EmpleadoService(WebServiceFeature ... features) {
        super(WSDL_LOCATION, SERVICE, features);
    }

    public EmpleadoService(URL wsdlLocation, WebServiceFeature ... features) {
        super(wsdlLocation, SERVICE, features);
    }

    public EmpleadoService(URL wsdlLocation, QName serviceName, WebServiceFeature ... features) {
        super(wsdlLocation, serviceName, features);
    }
    
    @WebEndpoint(name = "EmpleadoPort")
    public Empleado getEmpleadoPort() {
        return super.getPort(EmpleadoPort, Empleado.class);
    }
    
    @WebEndpoint(name = "EmpleadoPort")
    public Empleado getEmpleadoPort(WebServiceFeature... features) {
        return super.getPort(EmpleadoPort, Empleado.class, features);
    }

}
