package com.parameta.spingboot.app.empleados.validators;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.parameta.spingboot.app.empleados.models.Empleado;
import com.parameta.spingboot.app.empleados.models.EmpleadoDTO;

@Component("beforeCreateEmpleadoValidator")
public class EmpleadoValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return EmpleadoDTO.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		EmpleadoDTO empleado = (EmpleadoDTO)target;
		
		//Validar si los campos están vacios
		if(isNull(empleado.getNombre())) {
			errors.reject("nombre", "El nombre no debe ser vacío");
		}
		
		if(isNull(empleado.getApellidos())) {
			errors.reject("apellidos", "Apellido no debe ser vacío");
		}
		
		if(isNull(empleado.getTipoDocumento())) {
			errors.reject("tipoDocumento", "Tipo de documento no debe ser vacío");
		}
		
		if(isNull(empleado.getNumeroDocumento())) {
			errors.reject("numeroDocumento", "Número de documento no debe ser vacío");
		}
		
		if(isNull(empleado.getFechaNacimiento())) {
			errors.reject("fechaNacimiento", "Fecha de nacimiento no debe ser vacío");
		}
		
		if(isNull(empleado.getFechaVinculacion())) {
			errors.reject("fechaVinculacion", "Fecha de vinculación no debe ser vacío");
		}
		
		if(isNull(empleado.getCargo())) {
			errors.reject("cargo", "Cargo no debe ser vacío");
		}
		
		if(isNull(String.valueOf(empleado.getSalario()))) {
			errors.reject("salario", "Salario no debe ser vacío");
		}
		
		if(!isTipoValido(empleado.getTipoDocumento())) {
			errors.reject("tipoDocumento", "Tipo de documento debe ser CC o CE");
		}
		
		
		
		DateValidator dateValidator = new DateValidatorEmpleado();
		
		//Realizar validacion de fechas
		boolean esValidaFechaNacimiento = dateValidator.esValida(empleado.getFechaNacimiento());
		if(!esValidaFechaNacimiento) {
			errors.reject("fechaNacimiento", "La fecha de nacimiento debe tener el formato dd/MM/yyyy");
		}else {
			Period periodo = getEdad(empleado.getFechaNacimiento());
			if(periodo.getYears() < 18) {
				errors.reject("fechaNacimiento", "El empleado es menor de edad");
			}
		}
		
		boolean esValidafechaVinculacion = dateValidator.esValida(empleado.getFechaVinculacion());
		if(!esValidafechaVinculacion) {
			errors.reject("fechaVinculacion", "La fecha de vinculación debe tener el formato dd/mm/yyyy");
		}
		
	}
	
	/**
	 * Valida que el texto ingresado sea diferente a nulo y vacío
	 * @param string Texto a validar
	 * @return True si el texto es nulo o vacío
	 */
	private boolean isNull(String string) {
		return string == null || string.isEmpty();
	}
	
	/**
	 * Valida que el tipo de documento sea CC (cédula de ciudadanía) o
	 * CE (Cédula de extranjería)
	 * @param string Texto a validar
	 * @return true si es un tipo de documento válido
	 */
	private boolean isTipoValido(String string) {
		return string.equals("CC") || string.equals("CE");
	}
	
	/**
	 * Obtiene la edad del empleado
	 * @param FechaNacimiento Fecha de nacimiento del empleado
	 * @return Fecha en años, meses y días de nacido
	 */
	private Period getEdad(String FechaNacimiento) {
		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate fechaNac = LocalDate.parse(FechaNacimiento, fmt);
		LocalDate ahora = LocalDate.now();
		
		Period periodo = Period.between(fechaNac, ahora);
		return periodo;

	}

}
