package com.parameta.spingboot.app.empleados.controllers;

import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.validation.Valid;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.namespace.QName;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.parameta.spingboot.app.empleados.client.EmpleadoService;
import com.parameta.spingboot.app.empleados.models.Empleado;
import com.parameta.spingboot.app.empleados.models.EmpleadoDTO;
import com.parameta.spingboot.app.empleados.validators.EmpleadoValidator;

@RestController
@RequestMapping("/empleado")
public class EmpleadoController {
	
	private static final QName SERVICE_NAME = new QName("http://ws.empleados.app.jaxws.parameta.com/", "Empleado");
	
	@Autowired
    private EmpleadoValidator empleadoValidator;
	
	
	@InitBinder("empleadoDTO")
    public void initMerchantOnlyBinder(WebDataBinder binder) {
		binder.addValidators(empleadoValidator);
    }
	
	
	@PostMapping("/crear")
	@ResponseStatus(HttpStatus.CREATED)
	public Empleado crear(@Valid @RequestBody EmpleadoDTO empleadoDTO) {
		URL wsdlURL = EmpleadoService.WSDL_LOCATION;
		EmpleadoService ss = new EmpleadoService(wsdlURL, SERVICE_NAME);
		com.parameta.spingboot.app.empleados.client.Empleado port = ss.getEmpleadoPort();
		com.parameta.spingboot.app.empleados.client.EmpleadoDTO _saveEmpleado_empleado = 
					new com.parameta.spingboot.app.empleados.client.EmpleadoDTO();
		_saveEmpleado_empleado.setNombre(empleadoDTO.getNombre());
        _saveEmpleado_empleado.setApellidos(empleadoDTO.getApellidos());
        _saveEmpleado_empleado.setTipoDocumento(empleadoDTO.getTipoDocumento());
        _saveEmpleado_empleado.setNumeroDocumento(empleadoDTO.getNumeroDocumento());
        _saveEmpleado_empleado.setFechaNacimiento(getFecha(empleadoDTO.getFechaNacimiento()));
        _saveEmpleado_empleado.setFechaVinculacion(
					 getFecha(empleadoDTO.getFechaVinculacion()));	       
        _saveEmpleado_empleado.setCargo(empleadoDTO.getCargo());
        _saveEmpleado_empleado.setSalario(empleadoDTO.getSalario());
        java.lang.Boolean _saveEmpleado__return = port.saveEmpleado(_saveEmpleado_empleado);
        
		
		
		
		//boolean isCreate = empleadoClientSoap.saveEmpleado(empleado);
		return convertEmpleadoDTOTOEmpleado(_saveEmpleado_empleado);
		
	}
	
	public Date getFecha(String fecha) {
		DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		sdf.setLenient(false);
		try {
			return sdf.parse(fecha);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private Empleado convertEmpleadoDTOTOEmpleado(
			com.parameta.spingboot.app.empleados.client.EmpleadoDTO empleadoDTO) {
		Empleado empleado = new Empleado();
		empleado.setApellidos(empleadoDTO.getApellidos());
		empleado.setCargo(empleadoDTO.getCargo());
		empleado.setFechaNacimiento(empleadoDTO.getFechaNacimiento());
		empleado.setFechaVinculacion(empleadoDTO.getFechaVinculacion());
		empleado.setNombre(empleadoDTO.getNombre());
		empleado.setNumeroDocumento(empleadoDTO.getNumeroDocumento());
		empleado.setSalario(empleadoDTO.getSalario());
		empleado.setTipoDocumento(empleadoDTO.getTipoDocumento());
		empleado.setTiempoVinculacion(getPeriodos(empleadoDTO.getFechaVinculacion()));
		empleado.setEdadActual(getPeriodos(empleadoDTO.getFechaNacimiento()));
		
		return empleado;
	}
	
	private String getPeriodos(Date Fecha) {
		LocalDate fechaNac = Fecha.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		LocalDate ahora = LocalDate.now();
		
		Period periodo = Period.between(fechaNac, ahora);
		return periodo.getYears() + " años, " + periodo.getMonths() + 
				" meses y " + periodo.getDays() + " días";

	}

}
